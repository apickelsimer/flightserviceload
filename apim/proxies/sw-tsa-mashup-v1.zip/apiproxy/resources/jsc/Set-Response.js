var apResults = JSON.parse(context.getVariable("tsaResponse.content"));
var wtResults = JSON.parse(context.getVariable("response.content"));
var checkpoints = apResults[0].airport.checkpoints;
var waitTimes = wtResults.WaitTimes;

var wtLegend = {
    0 : "No Wait Time",
    1 : "1-10 min",
    2 : "11-20 min",
    3 : "21-30 min",
    4 : "31-45 min",
    5 : "46-60 min",
    6 : "61-90 min",
    7 : "91-120 min",
    8 : "120+ min",
}

var cpLegend= [];
for (var i=0; i < checkpoints.length; i++)
{
    cpLegend[i] = checkpoints[i].id;
}

var wtResults2 = [];
for (var y=0; y < waitTimes.length; y++)
{
    var cpID = cpLegend[parseInt(waitTimes[y].CheckpointIndex)];
    var wt = wtLegend[parseInt(waitTimes[y].WaitTime)];
    var wtDate = waitTimes[y].Created_Datetime;
    if (cpID !== null && cpID !== '' && cpID !== ' ' && cpID !== undefined) {
        wtResults2.push({
            "checkpointID": cpID,
            "waitTime": wt,
            "createdDatetime": wtDate
        });
    }
    else{
    wtResults2.push({
            "checkpointID": "unknown",
            "waitTime": wt,
            "createdDatetime": wtDate
        });
    }
}

var newResp = {
    AirportResult : apResults,
    WaitTimeResult : wtResults2
};

context.setVariable("response.header.Content-Type","application/json");
response.content = JSON.stringify(newResp);