var pdpResponse = context.getVariable("calloutResponse");
var pdpResponseJson = JSON.parse(pdpResponse);
context.setVariable("nextActionStatus",pdpResponseJson.Response.Decision);