var username = context.getVariable("request.header.username");
var password = context.getVariable("request.header.password");

if (username === 'andrew' && password === 'apigee')
{
    var user = {
        uid: "andrew",
        DN: "CN=andrew,CN=Users,DC=apigee,DC=com",
        givenName: "Andrew",
        sn: "Pickelsimer",
        mail: "apickelsimer@apigee.com",
        memberOf: "Domain Users,Apigeeks",
        scope: "app.read"
    }
    context.setVariable("response.header.Content-Type","application/json");
    context.setVariable("response.status.code","200");
    response.content = JSON.stringify(user);
}
else if (username === 'cass' && password === 'apigee')
{
    var user = {
        uid: "cass",
        DN: "CN=cass,CN=Users,DC=apigee,DC=com",
        givenName: "Cass",
        sn: "Obegron",
        mail: "cobregon@apigee.com",
        memberOf: "Domain Users,Apigeeks",
        scope: "app.read app.write app.delete"
    }
    context.setVariable("response.header.Content-Type","application/json");
    context.setVariable("response.status.code","200");
    response.content = JSON.stringify(user);
}
else
{
    var error = {
        message : "Invalid username and/or password."
    }
    context.setVariable("response.header.Content-Type","application/json");
    context.setVariable("response.status.code","403");
    response.content = JSON.stringify(error);
}

    