{
    "swagger": "2.0",
    "info": {
        "title": "Passenger",
        "description": "API services to manage passenger data",
        "version": "0.0.1"
    },
    "host": "demo26-test.apigee.net",
    "schemes": [
        "https"
    ],
    "basePath": "/v1/passenger",
    "paths": {
        "/": {
            "post": {
                "description": "Add a new passenger to the datastore",
                "parameters": [
                    {
                        "name": "passenger",
                        "in": "body",
                        "required": true,
                        "schema": {
                            "$ref": "#/definitions/Passenger"
                        }
                    }
                ],
                "responses": {
                    "201": {
                        "description": "default",
                        "schema": {
                            "$ref": "#/definitions/Response"
                        }
                    },
                    "404": {
                        "description": "default",
                        "schema": {
                            "$ref": "#/definitions/Error"
                        }
                    }
                }
            },
            "get": {
                "description": "List all passengers",
                "parameters": null,
                "responses": {
                    "200": {
                        "description": "default",
                        "schema": {
                            "$ref": "#/definitions/Passenger"
                        }
                    },
                    "404": {
                        "description": "default",
                        "schema": {
                            "$ref": "#/definitions/Error"
                        }
                    }
                }
            },
            "delete": {
                "description": "Delete a single or set of passengers",
                "parameters": [
                    {
                        "name": "uuid",
                        "in": "query",
                        "required": true,
                        "type": "string"
                    },
                    {
                        "name": "apikey",
                        "in": "query",
                        "required": true,
                        "type": "string"
                    }
                ],
                "responses": {
                    "200": {
                        "description": "default",
                        "schema": {
                            "$ref": "#/definitions/Response"
                        }
                    },
                    "404": {
                        "description": "default",
                        "schema": {
                            "$ref": "#/definitions/Error"
                        }
                    }
                }
            },
            "put": {
                "description": "Update an existing passenger",
                "parameters": [
                    {
                        "name": "passenger",
                        "in": "body",
                        "required": true,
                        "schema": {
                            "$ref": "#/definitions/Passenger"
                        }
                    },
                    {
                        "name": "apikey",
                        "in": "query",
                        "required": true,
                        "type": "string"
                    }
                ],
                "responses": {
                    "200": {
                        "description": "default",
                        "schema": {
                            "$ref": "#/definitions/Response"
                        }
                    },
                    "404": {
                        "description": "default",
                        "schema": {
                            "$ref": "#/definitions/Error"
                        }
                    }
                }
            }
        }
    },
    "definitions": {
        "Body": {
            "properties": {
                "bodyParam": {
                    "description": "default",
                    "type": "string"
                }
            }
        },
        "Response": {
            "properties": {
                "responseParam": {
                    "description": "default",
                    "type": "string"
                }
            }
        },
        "Error": {
            "properties": {
                "errorParam": {
                    "description": "default",
                    "type": "string"
                }
            }
        },
        "Passenger": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "uuid": {
                        "type": "string"
                    },
                    "type": {
                        "type": "string"
                    },
                    "created": {
                        "type": "integer"
                    },
                    "modified": {
                        "type": "integer"
                    },
                    "_id": {
                        "type": "string"
                    },
                    "about": {
                        "type": "string"
                    },
                    "address": {
                        "type": "string"
                    },
                    "age": {
                        "type": "integer"
                    },
                    "balance": {
                        "type": "string"
                    },
                    "company": {
                        "type": "string"
                    },
                    "email": {
                        "type": "string"
                    },
                    "eyeColor": {
                        "type": "string"
                    },
                    "firstName": {
                        "type": "string"
                    },
                    "freqFlyer": {
                        "type": "integer"
                    },
                    "gender": {
                        "type": "string"
                    },
                    "guid": {
                        "type": "string"
                    },
                    "index": {
                        "type": "integer"
                    },
                    "isActive": {
                        "type": "boolean"
                    },
                    "latitude": {
                        "type": "number"
                    },
                    "longitude": {
                        "type": "number"
                    },
                    "metadata": {
                        "type": "object",
                        "properties": {
                            "path": {
                                "type": "string"
                            }
                        }
                    },
                    "phone": {
                        "type": "string"
                    },
                    "picture": {
                        "type": "string"
                    },
                    "registered": {
                        "type": "string"
                    },
                    "surName": {
                        "type": "string"
                    },
                    "tags": {
                        "type": "array",
                        "items": {
                            "type": "string"
                        }
                    }
                }
            }
        }
    }
}